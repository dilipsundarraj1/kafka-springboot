package com.kafkaautomation.domain;

public enum WebhookEventType {
    NEW,
    UPDATE
}
